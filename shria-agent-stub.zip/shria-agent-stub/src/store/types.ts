export type ChallengeState = {
  currentDay: number;          // 1..7 (0 if not started)
  lastCompletedDay: number;    // 0..7
  lastSessionAt?: string;      // ISO timestamp
};

export type UserPrefs = {
  timeOfDay?: string;          // "13:00" local
  liked?: string[];            // e.g., ["4-7-8","body_scan"]
};

export type Reminder = {
  time: string;                // "HH:mm"
  label: string;
};

export type UserData = {
  userId: string;
  challenge: ChallengeState;
  prefs: UserPrefs;
  reminders: Reminder[];
};

export type EventRecord = {
  name: string;
  payload?: Record<string, any>;
  at: string; // ISO
};

export interface Store {
  getUser(userId: string): Promise<UserData>;
  upsertUser(user: UserData): Promise<void>;
  setChallengeDay(userId: string, day: number): Promise<UserData>;
  addEvent(userId: string, event: EventRecord): Promise<void>;
  setReminder(userId: string, reminder: Reminder): Promise<void>;
}
